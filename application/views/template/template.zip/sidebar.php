 <!-- Left side column. contains the logo and sidebar -->
            <aside class="left-side sidebar-offcanvas">
                <!-- sidebar: style can be found in sidebar.less -->
                <section class="sidebar">
                    <!-- Sidebar user panel -->
                    <div class="user-panel">
                        <div class="pull-left image">
                            <img src="<?= base_url('assets/template/')?>img/avatar3.png" class="img-circle" alt="User Image" />
                        </div>
                        <div class="pull-left info">
                            <p>Hello, Admin</p>

                            <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
                        </div>
                    </div>                   
                    <!-- /.search form -->
                    <!-- sidebar menu: : style can be found in sidebar.less -->
                    <ul class="sidebar-menu">
                        <li class="<?= ($this->uri->segment(1) == 'dashboard') ? 'active' : '' ?>">
                            <a href="<?= base_url('dashboard'); ?>">
                                <i class="fa fa-dashboard"></i> <span>Dashboard</span>
                            </a>
                        </li>

                        <li class="treeview <?= ($this->uri->segment(1) == 'admin') ? 'active' : '' ?>">
                            <a href="#">
                                <i class="fa fa-edit"></i> <span>Input Data</span>
                                <i class="fa fa-angle-left pull-right"></i>
                            </a>
                            <ul class="treeview-menu">
                                <li><a href="<?= base_url('admin'); ?>"><i class="fa fa-angle-double-right"></i> Data Sampah</a></li>
                                <li><a href="<?= base_url('sumber_sampah'); ?>"><i class="fa fa-angle-double-right"></i> Sumber Sampah</a></li>
                                <li><a href="<?= base_url('transporter'); ?>"><i class="fa fa-angle-double-right"></i> Transporter</a></li>
                                <li><a href="<?= base_url('jenissampah/komersil'); ?>"><i class="fa fa-angle-double-right"></i> Sampah Komersil</a></li>
                                <li><a href="<?= base_url('jenissampah/non_komersil'); ?>"><i class="fa fa-angle-double-right"></i> Sampah Non Komersil</a></li>
                            </ul>
                        </li>
                        <li class="treeview">
                            <a href="#">
                                <i class="fa fa-bar-chart-o"></i>
                                <span>Rekapitulasi</span>
                                <i class="fa fa-angle-left pull-right"></i>
                            </a>
                            <ul class="treeview-menu">
                                <li><a href="pages/charts/morris.html"><i class="fa fa-angle-double-right"></i> Sampah Komersil</a></li>
                                <li><a href="pages/charts/flot.html"><i class="fa fa-angle-double-right"></i> Sampah Non Komersil</a></li>
                            </ul>
                        </li>                     
                        <li class="treeview">
                            <a href="#">
                                <i class="fa fa-table"></i> <span>Report</span>
                                <i class="fa fa-angle-left pull-right"></i>
                            </a>
                            <ul class="treeview-menu">
                                <li><a href="pages/tables/simple.html"><i class="fa fa-angle-double-right"></i> Simple tables</a></li>
                                <li><a href="pages/tables/data.html"><i class="fa fa-angle-double-right"></i> Data tables</a></li>
                            </ul>
                        </li>
                        <li class="">
                            <a href="<?= base_url('logout'); ?>">
                                <i class="fa fa-sign-out"></i> <span>Log Out</span>
                            </a>
                        </li>
                    </ul>
                </section>
                <!-- /.sidebar -->
            </aside>